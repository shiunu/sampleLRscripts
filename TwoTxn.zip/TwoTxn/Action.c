Action()
{
	lr_start_transaction("S02_Full");
	
	lr_start_transaction("S02_T01_Txn1");
	
	web_save_timestamp_param("cTime1", LAST);
	
	lr_output_message(lr_eval_string("Timestamp: {cTime1}"));
	
	lr_think_time(5);

	lr_end_transaction("S02_T01_Txn1", LR_AUTO);
	
	lr_start_transaction("S02_T02_Txn2");
	
	web_save_timestamp_param("cTime1", LAST);
	
	lr_output_message(lr_eval_string("Timestamp: {cTime1}"));
	
	lr_think_time(10);

	lr_end_transaction("S02_T02_Txn2", LR_AUTO);
	
	lr_end_transaction("S02_Full", LR_AUTO);
	
	return 0;
}
